package pages_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Login_Page {
	
	WebDriver dr2;
	By eid = By.id("user-name");
	By pwd = By.id("password");
	By prd = By.className("product_label");
	By lgn_btn = By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");

	public Login_Page(WebDriver dr)
	{
		this.dr2 = dr;
	}
	
		public void enter_email(String emailid) {
		dr2.findElement(eid).sendKeys(emailid);
	}
	
	public void enter_password(String password) {
		dr2.findElement(pwd).sendKeys(password);
	}
	
	public void click_login_btn() {
		dr2.findElement(lgn_btn).click();	
	}
	
	public void do_login(String emailid,String password) {
		this.enter_email(emailid);
		this.enter_password(password);
		this.click_login_btn();
	}
	public void successful_login() {
		System.out.println("lofin success");
	}
	public String verify_text(WebDriver dr) {
		this.dr2 = dr;
		String st1 = dr2.findElement(prd).getText();
		return st1;
	}
}
