package pages_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProfilePage {
	By xp_profilename = By.xpath("/html/body/div/div[2]/div[2]/div/div[1]/div[3]/div");
	WebDriver dr3;
	public ProfilePage(WebDriver dr) {
		dr3 = dr;
	}
	public String get_profilename()
	{
		String pname = dr3.findElement(xp_profilename).getText();
		return pname;
	}
	
}
