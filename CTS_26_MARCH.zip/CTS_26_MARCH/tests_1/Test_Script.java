package tests_1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages_1.Home_Page;
import pages_1.Login_Page;
import pages_1.ProfilePage;

public class Test_Script {
	WebDriver dr;
	Home_Page hp;
	Login_Page lp;
	ProfilePage pp;
	
	@BeforeClass
	public void launchbrowser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com");
		pp = new ProfilePage(dr);
		lp = new Login_Page(dr);
		hp = new Home_Page(dr);
		}
	
	@Test
	public void logintest1()
	{
		String Title_str = hp.Verify_title();
		String exp_str = "Swag Labs";
		Assert.assertEquals(Title_str, exp_str);
		lp.do_login("standard_user","secret_sauce");
		lp.successful_login();
		String st1 = lp.verify_text(dr);
		System.out.println(st1);
		}
	}
