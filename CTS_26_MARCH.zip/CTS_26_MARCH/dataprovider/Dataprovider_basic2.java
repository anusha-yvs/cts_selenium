package dataprovider;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Dataprovider_basic2 {
	@Test(dataProvider="login_data")
	public void login(String eid, String pwd)
	{
	System.out.println("email id :" + eid + "pwd :" + pwd);	  
	}
	@DataProvider(name="login_data")
	public String[][] provide_data()
	{
		String[][] data= {
				{"e1","p1"},
				{"e2","p2"},
				{"e3","p3"}
		};
		return  data;
	}
}


